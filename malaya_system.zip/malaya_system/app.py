"""Web-Based Complaint and Feedback Management System
Barangay Malaya, Santo Domingo, Nueva Ecija  (IPT01 - Python / Flask)

Isang Flask application na may dalawang bahagi:
  1. Resident site  (/)        - para sa verified na taga-Malaya
  2. Admin/Staff    (/admin)   - para sa mga opisyal at staff ng barangay
"""
import os
import secrets
import sqlite3
from datetime import datetime
from functools import wraps

from flask import (Flask, abort, flash, g, redirect, render_template,
                   request, send_from_directory, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from i18n import DEFAULT_LANG, LANGS, translate, translate_value

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "malaya.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXT = {"png", "jpg", "jpeg"}

CATEGORIES = ["Basura at Kalinisan", "Ingay at Alitan", "Kalsada at Ilaw",
              "Tubig at Kuryente", "Peace and Order", "Suhestiyon at Papuri"]
STATUSES = ["Natanggap", "Sinusuri", "Inaaksyunan", "Naresolba"]
ASSIGNEES = ["Hindi pa naka-assign", "Kapitan", "Kagawad (Imprastraktura)",
             "Kagawad (Kalinisan)", "Tanod"]

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "palitan-ito-sa-production")
app.config["MAX_CONTENT_LENGTH"] = 3 * 1024 * 1024  # 3 MB na limit sa upload


# -------------------------------------------------------------- wika (i18n)
def current_lang():
    lang = session.get("lang", DEFAULT_LANG)
    return lang if lang in LANGS else DEFAULT_LANG


def T(key, **kw):
    """Isalin ang teksto sa napiling wika (para sa flash messages)."""
    return translate(key, current_lang(), **kw)


def reset_session():
    """Burahin ang session pero panatilihin ang napiling wika."""
    lang = session.get("lang")
    session.clear()
    if lang:
        session["lang"] = lang


@app.context_processor
def inject_i18n():
    lang = current_lang()
    return {"t": lambda key, **kw: translate(key, lang, **kw),
            "tr": lambda value: translate_value(value, lang),
            "lang": lang, "LANGS": LANGS}


@app.route("/lang/<code>")
def set_language(code):
    if code in LANGS:
        session["lang"] = code
    nxt = request.args.get("next", "")
    if not nxt.startswith("/") or nxt.startswith("//") or "\\" in nxt:
        nxt = url_for("home")
    return redirect(nxt)


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


@app.cli.command("init-db")
def init_db():
    """Gumawa ng database at mga default na account (flask init-db)."""
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    db = get_db()
    with open(os.path.join(BASE_DIR, "schema.sql"), encoding="utf-8") as f:
        db.executescript(f.read())
    db.execute("INSERT INTO staff (username, password_hash, full_name, role) VALUES (?,?,?,?)",
               ("admin", generate_password_hash("admin123"), "Barangay Admin", "Admin"))
    db.execute("INSERT INTO staff (username, password_hash, full_name, role) VALUES (?,?,?,?)",
               ("staff", generate_password_hash("staff123"), "Barangay Staff", "Staff"))
    db.commit()
    print("Tapos na. Admin: admin/admin123 | Staff: staff/staff123 (palitan agad!)")


# ------------------------------------------------------------ access control
def resident_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "resident_id" not in session:
            flash(T("need_login"))
            return redirect(url_for("resident_login"))
        return view(*args, **kwargs)
    return wrapped


def staff_required(*roles):
    """Kailangan ng staff login. Kapag may roles, dapat kasama ang role ng user."""
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "staff_id" not in session:
                return redirect(url_for("admin_login"))
            if roles and session.get("staff_role") not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


def allowed_file(name):
    return "." in name and name.rsplit(".", 1)[1].lower() in ALLOWED_EXT


# ====================================================== RESIDENT SITE (/)
@app.route("/")
def home():
    return render_template("home.html", categories=CATEGORIES)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("full_name", "").strip()
        contact = request.form.get("contact", "").strip()
        address = request.form.get("address", "").strip()
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        photo = request.files.get("id_file")

        if not (name and address and username and password):
            flash(T("fill_all"))
        elif len(password) < 6:
            flash(T("pw_len"))
        elif not photo or not photo.filename or not allowed_file(photo.filename):
            flash(T("id_upload"))
        else:
            db = get_db()
            if db.execute("SELECT 1 FROM residents WHERE username = ?", (username,)).fetchone():
                flash(T("username_taken"))
            else:
                ext = secure_filename(photo.filename).rsplit(".", 1)[1].lower()
                saved = f"{secrets.token_hex(8)}.{ext}"
                os.makedirs(UPLOAD_DIR, exist_ok=True)
                photo.save(os.path.join(UPLOAD_DIR, saved))
                db.execute(
                    "INSERT INTO residents (username, password_hash, full_name, contact,"
                    " address, id_file, created_at) VALUES (?,?,?,?,?,?,?)",
                    (username, generate_password_hash(password), name, contact,
                     address, saved, now()))
                db.commit()
                flash(T("reg_sent"))
                return redirect(url_for("resident_login"))
    return render_template("register.html")


@app.route("/login")
def login():
    """Pagpipilian: Admin o User (residente)."""
    return render_template("login_choice.html")


@app.route("/login/user", methods=["GET", "POST"])
def resident_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM residents WHERE username = ?",
                                (username,)).fetchone()
        if user is None or not check_password_hash(user["password_hash"], password):
            flash(T("bad_login"))
        elif user["status"] == "pending":
            flash(T("pending"))
        elif user["status"] == "rejected":
            flash(T("rejected"))
        else:
            reset_session()
            session["resident_id"] = user["id"]
            session["resident_name"] = user["full_name"]
            return redirect(url_for("file_complaint"))
    return render_template("login.html")


@app.route("/logout")
def logout():
    reset_session()
    return redirect(url_for("home"))


def new_tracking_no(db):
    last = db.execute("SELECT COALESCE(MAX(id), 0) FROM complaints").fetchone()[0]
    return f"MLY-{datetime.now().year}-{last + 1:04d}"


@app.route("/file", methods=["GET", "POST"])
@resident_required
def file_complaint():
    if request.method == "POST":
        category = request.form.get("category", "")
        location = request.form.get("location", "").strip()
        details = request.form.get("details", "").strip()
        anonymous = 1 if request.form.get("anonymous") else 0
        if category not in CATEGORIES:
            flash(T("pick_category"))
        elif not details:
            flash(T("need_details"))
        else:
            db = get_db()
            tn = new_tracking_no(db)
            db.execute(
                "INSERT INTO complaints (tracking_no, resident_id, category, location,"
                " details, anonymous, created_at) VALUES (?,?,?,?,?,?,?)",
                (tn, session["resident_id"], category, location, details, anonymous, now()))
            db.commit()
            flash(T("received", tn=tn))
            return redirect(url_for("track", tn=tn))
    return render_template("file.html", categories=CATEGORIES,
                           chosen=request.args.get("category", ""))


@app.route("/track")
@resident_required
def track():
    tn = request.args.get("tn", "").strip().upper()
    db = get_db()
    complaint, replies = None, []
    if tn:
        # Sariling reklamo lang ng residente ang makikita niya.
        complaint = db.execute(
            "SELECT * FROM complaints WHERE tracking_no = ? AND resident_id = ?",
            (tn, session["resident_id"])).fetchone()
        if complaint:
            replies = db.execute(
                "SELECT * FROM responses WHERE complaint_id = ? ORDER BY id",
                (complaint["id"],)).fetchall()
        else:
            flash(T("not_found"))
    mine = db.execute("SELECT tracking_no, category, status FROM complaints "
                      "WHERE resident_id = ? ORDER BY id DESC",
                      (session["resident_id"],)).fetchall()
    return render_template("track.html", tn=tn, complaint=complaint,
                           replies=replies, mine=mine, statuses=STATUSES)


# ================================================== ADMIN / STAFF (/admin)
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM staff WHERE username = ?",
                                (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            reset_session()
            session["staff_id"] = user["id"]
            session["staff_name"] = user["full_name"]
            session["staff_role"] = user["role"]
            return redirect(url_for("admin_dashboard"))
        flash(T("bad_login"))
    return render_template("admin/login.html")


@app.route("/admin/logout")
def admin_logout():
    reset_session()
    return redirect(url_for("admin_login"))


@app.route("/admin")
@staff_required()
def admin_dashboard():
    db = get_db()
    status = request.args.get("status", "")
    sql = ("SELECT c.*, r.full_name FROM complaints c "
           "JOIN residents r ON r.id = c.resident_id")
    params = ()
    if status in STATUSES:
        sql += " WHERE c.status = ?"
        params = (status,)
    complaints = db.execute(sql + " ORDER BY c.id DESC", params).fetchall()
    counts = {s: 0 for s in STATUSES}
    for row in db.execute("SELECT status, COUNT(*) n FROM complaints GROUP BY status"):
        counts[row["status"]] = row["n"]
    pending = db.execute("SELECT COUNT(*) FROM residents WHERE status = 'pending'").fetchone()[0]
    return render_template("admin/dashboard.html", complaints=complaints, counts=counts,
                           statuses=STATUSES, current=status, pending=pending)


@app.route("/admin/complaints/<int:cid>", methods=["GET", "POST"])
@staff_required()
def admin_complaint(cid):
    db = get_db()
    c = db.execute("SELECT c.*, r.full_name, r.contact FROM complaints c "
                   "JOIN residents r ON r.id = c.resident_id WHERE c.id = ?", (cid,)).fetchone()
    if c is None:
        abort(404)
    if request.method == "POST":
        status = request.form.get("status")
        assigned = request.form.get("assigned_to")
        message = request.form.get("message", "").strip()
        if status in STATUSES and assigned in ASSIGNEES:
            db.execute("UPDATE complaints SET status = ?, assigned_to = ? WHERE id = ?",
                       (status, assigned, cid))
            if message:
                db.execute("INSERT INTO responses (complaint_id, staff_id, message, created_at)"
                           " VALUES (?,?,?,?)", (cid, session["staff_id"], message, now()))
            db.commit()
            flash("Na-update ang reklamo.")
        return redirect(url_for("admin_complaint", cid=cid))
    replies = db.execute("SELECT r.*, s.full_name FROM responses r JOIN staff s ON s.id = r.staff_id"
                         " WHERE complaint_id = ? ORDER BY r.id", (cid,)).fetchall()
    return render_template("admin/complaint.html", c=c, replies=replies,
                           statuses=STATUSES, assignees=ASSIGNEES)


@app.route("/admin/residents")
@staff_required()
def admin_residents():
    rows = get_db().execute("SELECT * FROM residents ORDER BY "
                            "CASE status WHEN 'pending' THEN 0 ELSE 1 END, id DESC").fetchall()
    return render_template("admin/residents.html", residents=rows)


@app.route("/admin/residents/<int:rid>/<action>", methods=["POST"])
@staff_required()
def admin_resident_action(rid, action):
    if action not in ("approve", "reject"):
        abort(404)
    db = get_db()
    db.execute("UPDATE residents SET status = ? WHERE id = ?",
               ("verified" if action == "approve" else "rejected", rid))
    db.commit()
    return redirect(url_for("admin_residents"))


@app.route("/admin/residents/<int:rid>/id")
@staff_required()
def admin_resident_id(rid):
    """Staff lang ang puwedeng tumingin ng ID. Hindi ito public na folder."""
    row = get_db().execute("SELECT id_file FROM residents WHERE id = ?", (rid,)).fetchone()
    if row is None:
        abort(404)
    return send_from_directory(UPLOAD_DIR, row["id_file"])


@app.route("/admin/reports")
@staff_required("Admin")
def admin_reports():
    db = get_db()
    by_cat = db.execute("SELECT category, COUNT(*) n FROM complaints "
                        "GROUP BY category ORDER BY n DESC").fetchall()
    by_status = db.execute("SELECT status, COUNT(*) n FROM complaints GROUP BY status").fetchall()
    total = db.execute("SELECT COUNT(*) FROM complaints").fetchone()[0]
    return render_template("admin/reports.html", by_cat=by_cat, by_status=by_status, total=total)


@app.route("/admin/users", methods=["GET", "POST"])
@staff_required("Admin")
def admin_users():
    db = get_db()
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        name = request.form.get("full_name", "").strip()
        role = request.form.get("role", "Staff")
        password = request.form.get("password", "")
        if not (username and name and len(password) >= 6) or role not in ("Admin", "Staff"):
            flash("Punan ang lahat. Hindi bababa sa 6 na karakter ang password.")
        elif db.execute("SELECT 1 FROM staff WHERE username = ?", (username,)).fetchone():
            flash(T("username_taken"))
        else:
            db.execute("INSERT INTO staff (username, password_hash, full_name, role) VALUES (?,?,?,?)",
                       (username, generate_password_hash(password), name, role))
            db.commit()
            flash("Naidagdag ang user.")
        return redirect(url_for("admin_users"))
    users = db.execute("SELECT id, username, full_name, role FROM staff ORDER BY id").fetchall()
    return render_template("admin/users.html", users=users)


# --------------------------------------------------------------- errors
@app.errorhandler(403)
def forbidden(_e):
    return render_template("error.html", code=403, msg=T("err_403")), 403


@app.errorhandler(404)
def not_found(_e):
    return render_template("error.html", code=404, msg=T("err_404")), 404


if __name__ == "__main__":
    app.run(debug=True)
