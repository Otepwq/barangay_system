# Barangay Malaya – Complaint and Feedback Management System
IPT01 project (Python / Flask / SQLite)

## Paano patakbuhin (Windows)
    python -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    flask --app app init-db
    flask --app app run --debug

Buksan: http://127.0.0.1:5000  (resident site)  |  http://127.0.0.1:5000/admin  (admin/staff)

## Default na account (palitan agad)
- Admin: admin / admin123
- Staff: staff / staff123
- Residente: mag-register muna sa /register, tapos aprubahan ng admin/staff sa /admin/residents

## Istruktura
    app.py            mga route, login, role check, database
    schema.sql        mga table (staff, residents, complaints, responses)
    templates/        Jinja2 templates (resident) at templates/admin/ (admin/staff)
    static/           style.css at logo
    uploads/          mga ID na in-upload ng residente (hindi public)

Tandaan: itakda ang SECRET_KEY bilang environment variable bago i-deploy.
