"""Mga salin (translations): Tagalog (fil), Ilocano (ilo), English (en).

Para magdagdag ng bagong teksto: maglagay ng bagong key sa STRINGS na may
tatlong salin sa ayos na (fil, ilo, en), tapos gamitin sa template bilang
{{ t('key') }} o sa app.py bilang T('key').
"""

LANGS = {"fil": "Tagalog", "ilo": "Ilocano", "en": "English"}
DEFAULT_LANG = "fil"
_IDX = {"fil": 0, "ilo": 1, "en": 2}

STRINGS = {
    # --- header
    "language": ("Language", "Language", "Language"),
    "nav_home": ("Home", "Home", "Home"),
    "nav_file": ("Mag-file", "Agfile", "File"),
    "nav_track": ("I-track", "I-track", "Track"),
    "nav_login": ("Mag-login", "Sumrek", "Log in"),
    "nav_logout": ("Mag-logout", "Rummuar", "Log out"),

    # --- home
    "eyebrow": ("ONLINE NA SERBISYO NG BARANGAY", "ONLINE A SERBISIO TI BARANGAY", "ONLINE BARANGAY SERVICE"),
    "hero": ("Dinggin ang boses ng bawat taga-Malaya.",
             "Dengngen ti timek ti tunggal taga-Malaya.",
             "Every Malaya resident's voice is heard."),
    "lead": ("Mag-report ng problema o magbigay ng suhestiyon sa barangay. Makakakuha ka ng tracking number para masubaybayan ang aksyon.",
             "Agreport iti problema wenno mangted iti suhestion iti barangay. Makaalaka iti tracking number tapno masurot ti aksion.",
             "Report a problem or send a suggestion to the barangay. You'll get a tracking number to follow the action taken."),
    "btn_file": ("Mag-file ng Reklamo", "Agfile iti Reklamo", "File a Complaint"),
    "btn_track": ("I-track ang Reklamo", "Surotem ti Reklamo", "Track Your Complaint"),
    "btn_register": ("Mag-register", "Agrehistro", "Register"),
    "categories_heading": ("Mga kategorya ng reklamo", "Dagiti kategoria dagiti reklamo", "Complaint categories"),

    # --- login choice
    "choice_title": ("Mag-login bilang…", "Sumrek kas…", "Log in as…"),
    "choice_sub": ("Piliin kung paano ka papasok sa sistema.",
                   "Piliem no kasano ti panagserrekmo iti sistema.",
                   "Choose how you want to enter the system."),
    "role_admin": ("Admin", "Admin", "Admin"),
    "role_admin_desc": ("Para sa mga opisyal at staff ng barangay.",
                        "Para kadagiti opisial ken staff ti barangay.",
                        "For barangay officials and staff."),
    "role_user": ("User", "User", "User"),
    "role_user_desc": ("Para sa mga residente ng Malaya.",
                       "Para kadagiti residente ti Malaya.",
                       "For Malaya residents."),
    "no_account": ("Wala pang account?", "Awan pay ti accountmo?", "Don't have an account yet?"),
    "register_here": ("Mag-register dito", "Agrehistro ditoy", "Register here"),
    "back_to_choice": ("← Bumalik sa pagpili", "← Agsubli iti pilian", "← Back to choices"),

    # --- resident login
    "login_title": ("Para sa mga residente ng Malaya", "Para kadagiti residente ti Malaya", "For Malaya residents"),
    "login_desc": ("Kailangan ng account na beripikado ng barangay bago makapag-file ng reklamo.",
                   "Masapul ti account a naberipikar ti barangay sakbay a makapag-file iti reklamo.",
                   "You need an account verified by the barangay before you can file a complaint."),
    "username": ("Username", "Username", "Username"),
    "password": ("Password", "Password", "Password"),
    "login_btn": ("Mag-login", "Sumrek", "Log in"),

    # --- admin login page
    "admin_portal": ("Admin at Staff portal", "Admin ken Staff portal", "Admin and Staff portal"),
    "admin_login_desc": ("Para sa mga opisyal at staff ng barangay lamang.",
                         "Para laeng kadagiti opisial ken staff ti barangay.",
                         "For barangay officials and staff only."),

    # --- register
    "register_title": ("Mag-register", "Agrehistro", "Register"),
    "register_intro": ("Para matiyak na taga-Malaya ang nagrereklamo, ire-review muna ng barangay ang ID mo bago ka makapag-login.",
                       "Tapno maseguro a taga-Malaya ti agrekreklamo, rebbyuen nga umuna ti barangay ti ID-mo sakbay a makasumrekka.",
                       "To make sure complainants are from Malaya, the barangay will review your ID before you can log in."),
    "full_name": ("Buong pangalan", "Naan-anay a nagan", "Full name"),
    "contact": ("Contact number", "Contact number", "Contact number"),
    "address": ("Purok at address sa Malaya", "Purok ken address idiay Malaya", "Purok and address in Malaya"),
    "id_photo": ("Larawan ng valid ID o Barangay ID", "Ladawan ti valid ID wenno Barangay ID", "Photo of a valid ID or Barangay ID"),
    "register_submit": ("I-submit para ma-verify", "I-submit tapno maberipikar", "Submit for verification"),

    # --- file complaint
    "file_title": ("Mag-file ng Reklamo", "Agfile iti Reklamo", "File a Complaint"),
    "file_intro": ("Ilarawan ang problema nang malinaw. Mas maraming detalye, mas mabilis ang aksyon.",
                   "Iladawan a nalawag ti problema. Kaaduan a detalye, napardas ti aksion.",
                   "Describe the problem clearly. The more details, the faster the action."),
    "category": ("Kategorya", "Kategoria", "Category"),
    "location": ("Purok / Lokasyon", "Purok / Lugar", "Purok / Location"),
    "details": ("Detalye ng reklamo", "Detalye ti reklamo", "Complaint details"),
    "anonymous": ("Gusto kong mag-anonymous sa harap ng staff",
                  "Kayatko ti agbalin nga anonymous iti sangoanan dagiti staff",
                  "I want to stay anonymous to the staff"),
    "file_submit": ("I-submit ang Reklamo", "I-submit ti Reklamo", "Submit Complaint"),

    # --- track
    "track_title": ("I-track ang Reklamo", "Surotem ti Reklamo", "Track Your Complaint"),
    "tracking_no": ("Tracking number", "Tracking number", "Tracking number"),
    "search": ("Hanapin", "Biruken", "Search"),
    "no_location": ("Walang lokasyon", "Awan ti lokasyon", "No location"),
    "assigned": ("Assigned", "Naitudo", "Assigned"),
    "replies": ("Sagot ng barangay", "Sungbat ti barangay", "Barangay response"),
    "my_complaints": ("Mga reklamo ko", "Dagiti reklamok", "My complaints"),
    "th_tracking": ("Tracking", "Tracking", "Tracking"),
    "th_status": ("Status", "Status", "Status"),

    # --- errors
    "err_403": ("Walang access sa pahinang ito.", "Awan ti access iti daytoy a panid.", "You don't have access to this page."),
    "err_404": ("Hindi nahanap ang pahina.", "Saan a nasarakan ti panid.", "Page not found."),
    "back_home": ("Bumalik sa Home", "Agsubli iti Home", "Back to Home"),

    # --- flash messages
    "need_login": ("Mag-login muna bilang verified na residente ng Malaya.",
                   "Sumrek umuna kas verified a residente ti Malaya.",
                   "Please log in first as a verified Malaya resident."),
    "fill_all": ("Punan ang lahat ng kailangan.", "Punnuen amin a masapul.", "Please fill in all required fields."),
    "pw_len": ("Hindi bababa sa 6 na karakter ang password.",
               "Saan a basbassit ngem 6 a karakter ti password.",
               "Password must be at least 6 characters."),
    "id_upload": ("Mag-upload ng larawan ng ID (png, jpg, o jpeg).",
                  "Agi-upload iti ladawan ti ID (png, jpg, wenno jpeg).",
                  "Upload a photo of your ID (png, jpg, or jpeg)."),
    "username_taken": ("May gumagamit na ng username na iyan.",
                       "Adda ti agus-usar iti dayta a username.",
                       "That username is already taken."),
    "reg_sent": ("Naipadala na ang registration. Hintayin ang beripikasyon ng barangay.",
                 "Naipatulod ti registration. Urayen ti beripikasion ti barangay.",
                 "Registration sent. Please wait for the barangay to verify it."),
    "bad_login": ("Mali ang username o password.", "Biddut ti username wenno password.", "Wrong username or password."),
    "pending": ("Hinihintay pa ang beripikasyon ng barangay.",
                "Ur-uray pay ti beripikasion ti barangay.",
                "Waiting for the barangay's verification."),
    "rejected": ("Hindi na-verify ang account. Magpunta sa barangay hall.",
                 "Saan a naberipikar ti account. Mapanka iti barangay hall.",
                 "Account was not verified. Please go to the barangay hall."),
    "pick_category": ("Pumili ng kategorya.", "Mangpilika iti kategoria.", "Choose a category."),
    "need_details": ("Isulat ang detalye ng reklamo.", "Isurat ti detalye ti reklamo.", "Write the complaint details."),
    "received": ("Natanggap na ang reklamo mo. Tracking number: {tn}",
                 "Naawat ti reklamom. Tracking number: {tn}",
                 "We received your complaint. Tracking number: {tn}"),
    "not_found": ("Walang nahanap na reklamo. Tingnan ang tracking number.",
                  "Awan ti nasarakan a reklamo. Kitaen ti tracking number.",
                  "No complaint found. Check the tracking number."),
}

# Mga halagang naka-save sa database (nananatiling Tagalog doon);
# isinasalin lang kapag ipinapakita.
VALUES = {
    # categories
    "Basura at Kalinisan": ("Basura at Kalinisan", "Basura ken Kinadalus", "Garbage and Cleanliness"),
    "Ingay at Alitan": ("Ingay at Alitan", "Ariwengweng ken Riri", "Noise and Disputes"),
    "Kalsada at Ilaw": ("Kalsada at Ilaw", "Dalan ken Silaw", "Roads and Lights"),
    "Tubig at Kuryente": ("Tubig at Kuryente", "Danum ken Kuryente", "Water and Electricity"),
    "Peace and Order": ("Peace and Order", "Talna ken Urnos", "Peace and Order"),
    "Suhestiyon at Papuri": ("Suhestiyon at Papuri", "Suhestion ken Pammadayaw", "Suggestions and Compliments"),
    # statuses
    "Natanggap": ("Natanggap", "Naawat", "Received"),
    "Sinusuri": ("Sinusuri", "Sinusukimat", "Under review"),
    "Inaaksyunan": ("Inaaksyunan", "Maaksionan", "Being acted on"),
    "Naresolba": ("Naresolba", "Naresuelto", "Resolved"),
    # assignees
    "Hindi pa naka-assign": ("Hindi pa naka-assign", "Saan pay naitudo", "Not yet assigned"),
    "Kapitan": ("Kapitan", "Kapitan", "Barangay Captain"),
    "Kagawad (Imprastraktura)": ("Kagawad (Imprastraktura)", "Kagawad (Imprastruktura)", "Councilor (Infrastructure)"),
    "Kagawad (Kalinisan)": ("Kagawad (Kalinisan)", "Kagawad (Kinadalus)", "Councilor (Sanitation)"),
    "Tanod": ("Tanod", "Tanod", "Tanod"),
}


def _lang(lang):
    return lang if lang in _IDX else DEFAULT_LANG


def translate(key, lang, **kw):
    text = STRINGS[key][_IDX[_lang(lang)]]
    return text.format(**kw) if kw else text


def translate_value(value, lang):
    entry = VALUES.get(value)
    return entry[_IDX[_lang(lang)]] if entry else value
