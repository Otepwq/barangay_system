DROP TABLE IF EXISTS responses;
DROP TABLE IF EXISTS complaints;
DROP TABLE IF EXISTS residents;
DROP TABLE IF EXISTS staff;

CREATE TABLE staff (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('Admin', 'Staff'))
);

CREATE TABLE residents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    contact TEXT,
    address TEXT NOT NULL,
    id_file TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'verified', 'rejected')),
    created_at TEXT NOT NULL
);

CREATE TABLE complaints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tracking_no TEXT UNIQUE NOT NULL,
    resident_id INTEGER NOT NULL REFERENCES residents(id),
    category TEXT NOT NULL,
    location TEXT,
    details TEXT NOT NULL,
    anonymous INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'Natanggap',
    assigned_to TEXT NOT NULL DEFAULT 'Hindi pa naka-assign',
    created_at TEXT NOT NULL
);

CREATE TABLE responses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    complaint_id INTEGER NOT NULL REFERENCES complaints(id),
    staff_id INTEGER NOT NULL REFERENCES staff(id),
    message TEXT NOT NULL,
    created_at TEXT NOT NULL
);
